﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace GeeAdventureGame
{
   public class Story
    {
        public string[] contentArray = new string[22]
            {
              "\nYou start to blink your eyes open. You see your first mate standing over you.\nYour brain is a little foggy from being at sea so long... What was your adventurer name again?",     //index 0
                "What do you want to inspect? Choose a number below. ",     //index 1
                "       _.====.._\r\n         ,:._       ~-_\r\n             `\\        ~-_\r\n               | _  _  |  `.\r\n             ,/ /_)/ | |    ~-_\r\n    -..__..-''  \\_ \\_\\ `_      ~~--..__...----... AN OCEAN WAVE ...",     //index 2  ASCII-~ T a i k i  F u k u n a g a ~`.
                "You hear a huge crash. \n It seems that you've hit some land. That was a quite a mighty wave! \n You head off of the boat to access the damage.\nYour first mate seems to be okay...but your ship sure is damaged!",     //index 3
                "It's going to take a while to repair. On top of that, you've lost all of your items!!\nWhat a pain. You reminisce about the time you just spent looking at all of them.",     //index 4
                "You look out to the shoreline and see a forest and a huge expanse of grass. If you squint you can see a house in the distance. It's in the middle of the two. \n Where do you want to go first? Type in a number to choose.",     //index 5
                "You begin to journey towards the house. It is much further away than you originally thought... Well, there isn't really another choice here. \nYou see some flowers leading up to the house. You stoop down to pick some up and continue walking on.\nYou finally get to the house and knock on the door. A woman answers.",        //index 6
                "                        8o88o          __\r\n                      o88o           o688o)\r\n'-,    .``'.          _o8o    .-.'-.(6886898o\r\n   \\,'`   . \\.  .----| |-.  ,'     o688868698o)\r\n  .'  /   :   '/          \\'  \\  (68968886)6/88o\r\n /   '    '   /____________\\   '.  866\\88|889)\r\n/    .    \\   | ___   __   | .'  `   (969/9\\\r\n`           _ ||_|_| /  \\  |______     \\//  \\\r\n'.`\"'.`,`'./_\\||_|_| | .|  |______\\.`.`||,`,'\r\n`'^,_`'. ,\"|O||______|  |__|======|,.',|| ,..\r\n.'`. \"\\'^,`.,'.`'``.'/==\\.,.'`,.' `,' .||.,.`\r\n`',`' `,'.^ '. ,.'`,/====\\,' `,. ^, `.-',, `,\r\n.,`^  `. `,`  ,  ,`/======\\,  ,'  `'.,\"  ", // index 7 ASCII-Dariusz Ruman
                "\"My name is Circe. I live on this island and could use some help. I can think of a few things that need help around this island, for my healing plants and pet pigs. If you help me, in exchange, I will help you find the items to repair your ship and get home. I must warn you though, I have no patience if you ruin things on my property. You'll find out soon that things will go bad if you cross me.", //index 8
                "You receive a list of tasks from Circe. She tells you to come back after each one. Type in a number to get started on that task.", // index 9
                "You go back to the fence to see all of the pigs. They have some feed over to the side. Give them the feed or find some food in the forest? Type A or B.", // index 10
               "You feed them and go back to Circe. She gives you some barley in return. You take it back to your ship.",// index 11
                "You forage in the forest for some mushrooms and give it to the pigs. Circe is upset...Let's go do some other tasks so not to make her mad.", //index 12
                "Circe tells you to go find milkweek, jumiper, and yarrow. She's planted them somewhere in the garden. You go find them to give to her. She gives you some medical supplies, with the yarrow inside.", //index 13
                "You go back down to the shoreline to catch some sea bass. Circe gave you a fishing line to catch some fish. Are any biting? Choose A for yes and B for no. ", //index 14
                "There is some hay that is just laying around, maybe you should take that for bedding! Or you can cut down some of the softer grass to use. Choose A or B.", //index 15
                "You go into the woods to chop down some trees. There is an ax over there already. Now you have successfully chopped down some trees. Maybe you can use some of this wood to repair your ship. Circe gives you some rope to tie it together. You notice there are some pretty wild flowers to! Do you want to pick them? Choose A or B", //index 16
                "    )\\.-.     /`-.    )\\   )\\   )\\.---.         .-./(       .-.   )\\.---.    _/`-.\r\n   / .-._)  .' _  \\  (  './ /  (   .-._(      .'     )  )\\  /  ) (   .-._(  )  _  \\\r\n (  .   __ (  '-' (   )    (    \\  '-.       (   _  (  (  ) | (   \\  '-.   (  '-' (\r\n  ) '._\\ _) )   _  ) (  \\(\\ \\    ) .-`        ) (_)  ) )  \\/ /     ) .-`    )  _ .'\r\n (  .   (  (  /  ) \\  ).) /  )  (  ``-.      (      (  (     (    (  ``-.  (  ' ) \\\r\n  )/\\.__/   )/    )/ ( /  '.(    ).--.(       )/____/   )/../      ).--.(   )/   )/", // index 17 ASCII-textpaint.net
                "You have finally completed all of Circe's Tasks! Let's hope you didn't make her too upset so you are able to repair your ship and leave. Let's check out everything that you have collected so far to make sure you are good to go! Then you can say your last goodbyes.", //index 18
                "You can't leave now! There is still so much to repair on the ship. Plus, if Circe catches you running away, what will happen? It can't be good", //index 19
                "Congratulations! You've finished the game. ", // index 20 
                "1) Feed the pigs \n2) Find some herbs \n3)Catch some sea bass \n4)Collect sand \n5)Cut the grass \n6) Build a path to the beach \n7) Chop down some wood \n8) Prepare a fire \n9) Go back to the ship", //index 21

            };
    }
}
