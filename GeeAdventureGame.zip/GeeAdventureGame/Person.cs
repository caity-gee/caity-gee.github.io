﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeeAdventureGame
{
    public class Person
    {
        public string characterName;
        public Person()
        {
            // Does nothing but create object
        }

        public void setName(string _characterName)
        {
            this.characterName = _characterName;
        }
    }
}
