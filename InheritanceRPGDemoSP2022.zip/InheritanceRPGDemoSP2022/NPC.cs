﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceRPGDemoSP2022
{
    //setting the access modifier to public
    //npc class is built to be a base class
    public class NPC
    {
        //create the variables for the base class model
        //use the "protected" keyword to make variables "inheritable"
        protected int npcHealthPoints;
        protected string npcClassName;
        protected int npcxpValue;

        //create the basic constructor
        public NPC()
        { 
            
        }

        //create a HUD method for the npc base class
        public void NPCHUD()
        {
            //print var values
            Console.WriteLine("NPC Class: {0}", this.npcClassName);
            Console.WriteLine("NPC HealthPoints: " + this.npcHealthPoints);
        }

        //create a public property to get the npc health point value
        public int GetNPCHealthPoints
        {
            get { return this.npcHealthPoints; }
        }

        //create a public property to set the npc healthpoint value
        public int SetNPCHealthPoints
        {
            set { this.npcHealthPoints = value; }
        }

        //create a public property to read npc class
        public string GetNPCClassName
        {
            get { return this.npcClassName; }
        }

        //create a public property to read npc npcxpValue
        public int GetNPCXPValue
        {
            get { return this.npcxpValue; }
        }

    }
}
