﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceRPGDemoSP2022
{
    //setting the access modifier to public
    //inherit from the charcter base class
    public class Wizard : Character
    {
        //create a var for wizrad to inflist spell damage
        int spellDamage;

        //marry the child class constructor
        //with the base class constructor
        //input parameters must match
        public Wizard(string _charName) : base(_charName)
        {
            //set default values for the wizard
            this.charClass = "Wizard";
            this.damage = 10;
            this.spellDamage = 20;
        }

        //create a custom property for the wizard class to cast spells
        public int CastSpell
        {
            get { return this.spellDamage; }
        }
    }
}
