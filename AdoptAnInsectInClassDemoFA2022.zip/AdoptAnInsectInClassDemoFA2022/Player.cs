﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoptAnInsectInClassDemoFA2022
{
    //set the access modifier to public
    public class Player
    {
        //add vars
        public Insect adoptee;
        public string playerName;

        //creaet an overloaded constructor with one input parameter
        //for playername
        public Player(string _playerName)
        {
            //marry the input parameter with the local var
            this.playerName = _playerName;
        }

        //creaet a method to adopt an insect
        public void Adopt(string _name, string _species, string _color, bool _hasWings)
        {
            //instantiate an insect and pass the input parameters
            //as values into the Insect class constrctor
            adoptee = new Insect(_name, _species, _color, _hasWings);

            //clear the console
            Console.Clear();

            //narrative
            Console.WriteLine($"Congratulation {this.playerName}!");
            Console.WriteLine($"\nYou have just adopted {adoptee.name} the {adoptee.color} {adoptee.species}.");
        }

    }
}
