﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceRPGDemoSP2022
{
    //set access modifier to public
    public class Story
    {
        //create a content array and populate with content
        public string[] contentArray = new string[11]
            {
                "Welcome to the Adventure Game. \nYou will meet several foes in your travels. Defeat them to earn Experience Points and Useful Items. \nCollect 3 rings to win.\n\nLet's start by creating a Ranger. \nWhat is you Ranger's name?",     //index 0
                "Press enter to continue",     //index 1
                "Press enter to create a Wizard...",     //index 2
                "Let's start the adventure.",     //index 3
                "Please make a valid selection.",     //index 4
                "By defeating the Orc your adventure party has found the silver ring. \nThe first of three rings needed to save the kingdom.\n",     //index 5
                "You may choose to explore the cave or the forest.\n\nEnter 1) to explore the Cave or 2) for the forest.\n",     //index 6
                "You have chosen to explore the cave.\nA bugbear attacks.\nDefeat the buggear and you might be able to find the second ring!",     //index 7
                "You have chosen to explore the forest.\nA Minotaur attacks.\nDefeat the Minotaur and you might be able to find the second ring!",     //index 8
                "By defeating the Bugbear your adventure party has found the platinum ring. \nThe second of three rings needed to save the kingdom.\n" ,     //index 9
                "By defeating the Minotaur your adventure party has found the bronze ring. \nThe second of three rings needed to save the kingdom.\n"      //index 10
            };




    }
}
