﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceRPGDemoSP2022
{
    //ranger class will inherit from the character base class
    //set the access modifier to public
    public class Ranger : Character
    {
        //create aa constructor for the child class
        //marry it to the base class constructor
        public Ranger(string _charName) : base(_charName)
        {
            //set default values for the ranger class here
            this.charClass = "Ranger";
            this.damage = 5;
        }
    }
}
