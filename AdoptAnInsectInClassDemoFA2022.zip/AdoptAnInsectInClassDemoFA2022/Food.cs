﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoptAnInsectInClassDemoFA2022
{
    //set the access modifier to public
    public class Food
    {
        //creating two vars
        public string foodName;
        public int energyValue;

        //create an overloaded constructor for the food class
        //two input parameters
        public Food(string _foodName, int _energyValue)
        {
            //marry our input parameters to local vars
            this.foodName = _foodName;
            this.energyValue = _energyValue;
        }

    }
}
