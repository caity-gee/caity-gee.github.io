﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceRPGDemoSP2022
{
    class Program
    {
        static void Main(string[] args)
        {
            //create an instance of the game
            Game myGame1 = new Game();

            //perform the playgame method call
            myGame1.PlayGame();
        }
    }
}
