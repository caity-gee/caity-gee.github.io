﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceRPGDemoSP2022
{
    //this will be a child class
    //inheriting from the NPC base class
    //setting the access modifier to public
    public class Orc : NPC
    {
        //create a basic constructor in order to set default values
        public Orc() : base()
        {
            //set some default values
            this.npcHealthPoints = 200;
            this.npcClassName = "Orc";
            this.npcxpValue = 100;

        }
    }
}
