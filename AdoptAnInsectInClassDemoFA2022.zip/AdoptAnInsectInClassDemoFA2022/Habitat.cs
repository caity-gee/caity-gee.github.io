﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoptAnInsectInClassDemoFA2022
{
    //set the access modifier to public
    public class Habitat
    {
        //add the vars
        public string habitatName;
        public double temperature;

        //create a constructor
        public Habitat()
        {
            //set default values
            this.habitatName = "Terrarium";
            this.temperature = 65;
        }

        //create a methois to tell us about the habitat
        public void HabitatInfo()
        {
            Console.WriteLine($"The {this.habitatName} has a current temperature of {this.temperature} degrees F.");
        }

        //create a methoid to change temperature
        //include an input parameter for the change delta
        public void ChangeTemperature(double _tempChangeValue)
        {
            this.temperature = _tempChangeValue + this.temperature;
        }
    }
}
