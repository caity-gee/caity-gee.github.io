﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoptAnInsectInClassDemoFA2022
{
    //set the access modifer to public 
    public class Insect
    {
        //add our vars
        public string name;
        public string species;
        public string color;
        public bool hasWings;
        public int energy;

        //build the about method
        public void About()
        {
            //this method will tell us information about
            //the insect and its energy value
            Console.WriteLine($"{this.name} the {this.species} has {this.energy} energy remaining.");
        }

        //build an overloaded constructor with 4 input parameters
        public Insect(string _name, string _species, string _color, bool _hasWings)
        {
            //marry the input parameters to
            //the local vars
            this.name = _name;
            this.species = _species;
            this.color = _color;
            this.hasWings = _hasWings;

            //set the default value for energy
            this.energy = 2;
        }

        //build an eat method to increae energy
        //via one input parameter
        public void Eat(int _foodInput)
        {
            //print to screen that the insect has eaten
            //increase the energy vlaue by the input value
            Console.WriteLine($"{this.name} has just eaten a meal.");
            this.energy = _foodInput + this.energy;
        }

        //create a method to fly
        public void Fly()
        {

            //print to screen that our insect will fly
            Console.WriteLine($"{this.name} the {this.species} has flown around its habitat and burned some energy.");

            this.energy = this.energy--;

        }
    }
}
