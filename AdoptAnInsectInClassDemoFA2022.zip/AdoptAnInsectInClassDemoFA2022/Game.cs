﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoptAnInsectInClassDemoFA2022
{
    //set the access midifier to public
    public class Game
    {
        //create the vars
        public string playerNameInput;
        public int playerInsectIDInput;
        public int playerTemperatureInput;

        //objects
        Player player1;
        Habitat myHabitat;
        Food insectFood;

        //create a method that wil run the appliaction
        public void Startup()
        {
            Intro();
        }

        //build a method to run the intro
        public void Intro()
        {
            //welcome the player
            Console.WriteLine("Welcome to Adopt-an-Insect 2022.");
            Console.WriteLine("This application will help you to adopt an insect.");
            Console.WriteLine("\nPlease enter your name:");

            //pass the user input into the playerNameInput var
            playerNameInput = Console.ReadLine();

            //clear the console
            Console.Clear();

            //instantiate the player object
            player1 = new Player(playerNameInput);

            //give feedback
            Console.WriteLine($"{player1.playerName}, thank youfor stopping by the pet store.");

            Console.WriteLine("We haev several insects available for adoption today.");
            Console.WriteLine("Please select an insect from the list below by netering its number.");
            Console.WriteLine("\n1) Gary the Green Mantis");
            Console.WriteLine("\n2) Manuel the Red and Blck Lady Bug or");
            Console.WriteLine("\n3) Jie the Purple Cricket");

            //convert the user input string into an int and store teh value
            //in a var
            playerInsectIDInput = Convert.ToInt32(Console.ReadLine());

            //use conditional branching to determine which values to push to the insect constructor for adoption
            if (playerInsectIDInput == 1)
            {
                player1.Adopt("Gary", "Mantis", "Green", true);
            }

            else if (playerInsectIDInput == 2)
            {
                player1.Adopt("Manuel", "Lady Bug", "Red and Black", true);
            }

            else if (playerInsectIDInput == 3)
            {
                player1.Adopt("Jie", "Cricket", "Purple", true);
            }

            Console.ReadLine();


        }
    }
}
