﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Credits to Caity Gee

namespace GeeAdventureGame
{
    public class Game
    {
        // Variables
        static string characterName;

        // Objects
        Player player1;
        Circe circe1;
        Story myStory1 = new Story();
        Inventory myInventory1 = new Inventory();
        //how to show flowers
        


        public void Startup()
        {
            Intro();
            ExploreDeck();
            CrashTheShip();
            MeetCirce();
            CirceTasks();
            Ending();
        }

        public void Intro()
        {
            // Introductory Text
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Hey!");
            Console.WriteLine("\nWake up!");
            Console.ResetColor();
            Console.WriteLine(myStory1.contentArray[0]);

            // Ask for the player's name, and then create a new player object with that name
            characterName = Console.ReadLine();
            player1 = new Player();
            circe1 = new Circe();
            player1.setName(characterName);

            Console.ForegroundColor= ConsoleColor.Cyan; 
            Console.WriteLine($"'Ahoy, {player1.characterName}!'");
            Console.ResetColor();
            Console.ReadKey();
            Console.Clear();
        }

        public void ExploreDeck()
        {
            string input = "";
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"Cap'n {player1.characterName}, it's been quite some time since we have been together. Let's take inventory of what's on the ship. Where do you want to start, Top Deck or Bottom Deck?");
            Console.ResetColor();
            input = Console.ReadLine();
            input = input.ToLower();
            if (input == "top deck")
            {
                Console.WriteLine("You've chosen the Top Deck!");
                ExploreTopDeck();
                Console.Clear();

                Console.Write("You've checked the Top Deck, and will now proceed to the Bottom Deck.");
                ExploreBottomDeck();
                Console.Clear();
            }
            else if (input == "bottom deck")
            {
                Console.WriteLine("You've chosen the Bottom Deck!");
                ExploreBottomDeck();
                Console.Clear();

                Console.Write("You've checked the Bottom Deck, and will now proceed to the Top Deck.");
                ExploreTopDeck();
                Console.Clear();
            }
            else
            {
                Console.WriteLine("We'll just start top to bottom then.");
                ExploreTopDeck();
                Console.Clear();

                Console.Write("You've checked the Top Deck, and will now proceed to the Bottom Deck.");
                ExploreBottomDeck();
                Console.Clear();
            }

        }

        public void ExploreTopDeck()
        {
            int TopDeckItems = 0;
            int BucketCheck = 0;
            int RopeCheck = 0;
            int PlankCheck = 0;
            int MedicalSuppliesCheck = 0;

            Console.WriteLine("You enter the top deck and see the following items:");
            Console.WriteLine("1) Bucket");
            Console.WriteLine("2) Rope");
            Console.WriteLine("3) Planks");
            Console.WriteLine("4) Medical Supplies");
            Console.WriteLine("5) Leave");

            while (TopDeckItems != 5)
            {
                Console.Write(myStory1.contentArray[1]);

                TopDeckItems = Convert.ToInt32(Console.ReadLine());


                switch (TopDeckItems)
                {
                    case 1:
                        Console.WriteLine("You have found a bucket! What to do with it... Maybe you should keep it.");
                        player1.GainXP(5);
                        BucketCheck = 1;
                        break;
                    case 2:
                        Console.WriteLine("Some...rope? Seems useful to have on a ship. You put it in your pocket.");
                        player1.GainXP(5);
                        RopeCheck = 1;
                        break;
                    case 3:
                        Console.WriteLine("These planks could be useful later.");
                        player1.GainXP(5);
                        PlankCheck = 1;
                        break;
                    case 4:
                        Console.WriteLine("Some medical supplies! Luckily you don't need that...yet.");
                        player1.GainXP(5);
                        MedicalSuppliesCheck = 1;
                        break;
                    case 5:
                        if (BucketCheck + RopeCheck + PlankCheck + MedicalSuppliesCheck == 4)
                        {
                            Console.WriteLine("You've checked all the items and will move on.");
                            break;
                        }
                        else 
                        {
                            Console.WriteLine("Huh, seems like you've missed checking something out.");
                            TopDeckItems = 0;
                            break;
                        }
                    default:
                        Console.WriteLine("That doesn't seem to be on the ship...Maybe try again?");
                        break;
                }
            }
        }

        public void ExploreBottomDeck()
        {
            int BottomDeckItems = 0;
            int BarleyCheck = 0;
            int MapCheck = 0;
            int CompassCheck = 0;
            int BeddingCheck = 0;

            Console.WriteLine("You enter the bottom deck and see the following items:");
            Console.WriteLine("1) Barley");
            Console.WriteLine("2) Map");
            Console.WriteLine("3) Compass");
            Console.WriteLine("4) Bedding");
            Console.WriteLine("5) Leave");

            while(BottomDeckItems != 5)
            {
                Console.Write(myStory1.contentArray[1]);

                BottomDeckItems = Convert.ToInt32(Console.ReadLine());

                switch (BottomDeckItems)
                {
                    case 1:
                        Console.WriteLine("You have found some barley! How do you cook with this again?");
                        player1.GainXP(5);
                        BarleyCheck = 1;
                        break;
                    case 2:
                        Console.WriteLine("A map is definitely going to come in handy. You put it in your pocket.");
                        player1.GainXP(5);
                        MapCheck = 1;
                        break;
                    case 3:
                        Console.WriteLine("These planks could be useful later.");
                        player1.GainXP(5);
                        CompassCheck = 1;
                        break;
                    case 4:
                        Console.WriteLine("Some medical supplies! Luckily you don't need that...yet.");
                        player1.GainXP(5);
                        BeddingCheck = 1;
                        break;
                    case 5:
                        if (BarleyCheck + MapCheck + CompassCheck + BeddingCheck == 4)
                        {
                            Console.WriteLine("You've checked all the items and will move on.");
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Huh, seems like you've missed checking something out.");
                            BottomDeckItems = 0;
                            break;
                        }
                    default:
                        Console.WriteLine("That doesn't seem to be on the ship...Maybe try again?");
                        break;
                }
            }
        }


        public void CrashTheShip()
        {
            int LandChoice = 0;
            int HouseCheck = 0;


            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"Cap'n, {player1.characterName} ! You better come up here. I think I see something in the distance!");
            Console.ResetColor();
            Console.WriteLine("You begin to make your way towards your first mate but as you do there is a huge rock of the boat!");
            Console.ReadKey();
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine(myStory1.contentArray[2]);
            Console.ResetColor();
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine(myStory1.contentArray[3]);
            Console.ReadKey();
            Console.WriteLine(myStory1.contentArray[4]);
            Console.ReadKey();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"Well, Cap'n {player1.characterName}, seems like we lost a whole lotta stuff in that crash. Guess we should see where we end up.");
            Console.ResetColor();
            Console.WriteLine(myStory1.contentArray[5]);
            Console.WriteLine("1) Explore the Shoreline");
            Console.WriteLine("2) Explore the Forest");
            Console.WriteLine("3) Explore the Grassland");
            Console.WriteLine("4) Go to the House");

            while (HouseCheck != 1)
            {
                LandChoice = Convert.ToInt32(Console.ReadLine());

                switch (LandChoice)
                {
                    case 1:
                        Console.WriteLine("You poke around the shoreline. Everything seems like it is lost. You should really move away from the ship");
                        Console.WriteLine("Where else do you want to go? ");
                        player1.GainXP(10);
                        break;
                    case 2:
                        Console.WriteLine("You start to head towards the forest. It isn't as far away as you thought. It looks surprisingly well taken care of. You start to be able to see a garden and look around. There are some pretty flowers growing! You bend down to pick one. \n Break time is over! Time to keep exploring.");
                        Console.WriteLine("Where else do you want to go? ");
                        player1.GainXP(10);
                        player1.gatherFlowers(1);
                        break;
                    case 3:
                        Console.WriteLine("You walk to the grasslands. It is super muddy, like it just rained. The closer you get, the more you start to see the edges of a pigpen. There are plenty of pigs here! Someone must be taking care of them. You should go and see if they will share with you.");
                        Console.WriteLine("Where else do you want to go? ");
                        player1.GainXP(10);
                        break;
                    case 4:
                        Console.WriteLine("You make your way to the house not knowing what to expect. Who's living on this deserted island?");
                        player1.GainXP(50);
                        HouseCheck = 1;
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    default:
                        Console.WriteLine("Well, you gotta go somewhere. You can't hang out by your broken ship forever.");
                        Console.WriteLine("Where else do you want to go? ");
                        break;
                }
            }

        }

        public void MeetCirce()
        {
            Console.WriteLine(myStory1.contentArray[6]);
            player1.gatherFlowers(2);
            Console.WriteLine(myStory1.contentArray[7]);
            Console.ReadKey();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("Hmmmmm... A traveler. I don't get too many of those. What brings you here?");
            Console.ResetColor();
            Console.ReadKey();
            Console.WriteLine($"\nMy name is {player1.characterName}. I was traveling home, but a huge wave hit our ship and we have no more supplies! Is there anyway that you may be able to help us?");
            Console.ReadKey();
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine(myStory1.contentArray[8]);
            Console.ResetColor();
            Console.WriteLine("\nCirce starts off at 100 points that will decrease each time she gets mad. If you make her too upset, she'll turn you into a pig and you will never get to leave!");
            Console.ReadKey();
            Console.Clear();
        }

        public void UpdateInventory()
        {
            Console.WriteLine("Inventory:");
            foreach(string i in myInventory1.inventoryList)
            {
                Console.WriteLine(i);
            }
        }

        public void CirceTasks()
        {
            Console.WriteLine(myStory1.contentArray[9]);
            int CirceTask = 0;
            Console.WriteLine(myStory1.contentArray[21]);

            while (CirceTask != 8)
            {
                CirceTask = Convert.ToInt32(Console.ReadLine());
                string response;

                switch (CirceTask)
                {
                    case 1:
                        Console.WriteLine(myStory1.contentArray[10]);
                        response = Console.ReadLine();
                        response = response.ToUpper();
                        if (response == "A")
                        { Console.WriteLine(myStory1.contentArray[11]);
                            player1.addInventoryItem(4);
                            myInventory1.inventoryList.Add("barley");
                            player1.GainXP(10);
                        }
                        else
                        { Console.WriteLine(myStory1.contentArray[12]);
                            Console.WriteLine("Circe deducts 15 points.");
                            circe1.MadPoints(-15);
                        }
                        CirceTask = 1;
                        UpdateInventory();
                        Console.ReadKey();
                        Console.Clear();
                        Console.WriteLine(myStory1.contentArray[21]);
                        break;
                    case 2:
                        Console.WriteLine(myStory1.contentArray[13]);
                        player1.gatherFlowers(3);
                        player1.addInventoryItem(3);
                        myInventory1.inventoryList.Add("medical supplies");
                        player1.GainXP(10);
                        CirceTask = 1;
                        UpdateInventory();
                        Console.ReadKey();
                        Console.Clear();
                        Console.WriteLine(myStory1.contentArray[21]);
                        break;
                    case 3:
                        Console.WriteLine(myStory1.contentArray[14]);
                        response = Console.ReadLine();
                        response = response.ToUpper();
                        if (response == "A")
                        {
                            Console.WriteLine("You caught some sea bass! Circe will be happy to cook later. She gives you a toolkit and a compass.");
                            player1.addInventoryItem(6);
                            myInventory1.inventoryList.Add("compass");
                            player1.GainXP(10);
                        }
                        else
                        {
                            Console.WriteLine("Doesn't seem like any fish are biting...by the way are pigs even native to this island?");
                            Console.WriteLine("Circe deducts 15 points.");
                            circe1.MadPoints(-15);
                        }
                        CirceTask=1;
                        UpdateInventory();
                        Console.ReadKey();
                        Console.Clear();
                        Console.WriteLine(myStory1.contentArray[21]);
                        break;
                    case 4:
                        Console.WriteLine("You go back to your ship and collect some sand around the areas. You see some flowers growing. Should you pick them? Choose A for yes or B for no.");
                        response = Console.ReadLine();
                        response = response.ToUpper();
                        if (response == "A")
                        { player1.gatherFlowers(1); }
                        player1.GainXP(10);
                        CirceTask = 1;
                        Console.WriteLine("Press enter to continue");
                        Console.ReadKey();
                        Console.Clear();
                        Console.WriteLine(myStory1.contentArray[21]);
                        break;
                    case 5:
                        Console.WriteLine(myStory1.contentArray[15]);
                        response = Console.ReadLine();
                        response = response.ToUpper();
                        if (response == "A")
                        { Console.WriteLine("Circe won't notice if you take a little...");
                            Console.WriteLine("Circe deducts 15 points.");
                            circe1.MadPoints(-15);
                            Console.ReadKey();
                        }
                        else
                        { Console.WriteLine("You can lay out the grass on the ship to dry out.");
                            player1.addInventoryItem(7);
                            myInventory1.inventoryList.Add("bedding");
                            player1.GainXP(10);
                        }
                        CirceTask = 1;
                        UpdateInventory();
                        Console.ReadKey();
                        Console.Clear();
                        Console.WriteLine(myStory1.contentArray[21]);
                        break;
                    case 6:
                        Console.WriteLine("Now that you have a toolbox, you can build a path to the beach! But, you need something to carry all of your materials in...You see a familiar bucket near the pigs...");
                        player1.addInventoryItem(0);
                        myInventory1.inventoryList.Add("bucket");
                        player1.GainXP(10);
                        CirceTask = 1;
                        UpdateInventory();
                        Console.WriteLine("You've built a path to the beach!");
                        Console.ReadKey();
                        Console.Clear();
                        Console.WriteLine(myStory1.contentArray[21]);
                        break;
                    case 7:
                        Console.WriteLine(myStory1.contentArray[16]);
                        player1.addInventoryItem(1);
                        myInventory1.inventoryList.Add("rope");
                        player1.GainXP(10);
                        response = Console.ReadLine();
                        response = response.ToUpper();
                        if (response == "A")
                        { player1.gatherFlowers(1); }
                        CirceTask = 1;
                        UpdateInventory();
                        Console.ReadKey();
                        Console.Clear();
                        Console.WriteLine(myStory1.contentArray[21]);
                        break;
                    case 8:
                        Console.WriteLine("This fire will be useful for upcoming evenings while you repair your ship. You can now also cook your barley. Circe gives you a map to look at while you stare at the fire.");
                        player1.GainXP(10);
                        player1.addInventoryItem(5);
                        myInventory1.inventoryList.Add("map");
                        player1.addInventoryItem(2);
                        myInventory1.inventoryList.Add("planks");
                        UpdateInventory();
                        Console.ReadKey();
                        Console.Clear();
                        Console.WriteLine(myStory1.contentArray[21]);
                        break;
                    case 9:
                        Console.WriteLine(myStory1.contentArray[19]);
                        Console.WriteLine("Circe deducts 15 points.");
                        circe1.MadPoints(-15);
                        Console.ReadKey();
                        Console.Clear();
                        Console.WriteLine(myStory1.contentArray[21]);
                        break;
                    default:
                        Console.WriteLine("If you don't do any of the tasks, Circe threatens to turn you into a pig! You glance at the pigs on the island and sigh. Guess you'll be living on this island for a while...");
                        Console.WriteLine(myStory1.contentArray[17]);
                        Console.ReadKey();
                        CirceTask = 8;
                        break;

                }
            }
        }

        public void Ending()
        {
            Console.Clear();
            Console.WriteLine(myStory1.contentArray[18]);
            UpdateInventory();
            player1.showXP();
            player1.showFlowers();
            Console.WriteLine($"{circe1.points} points remaining");

            if (circe1.points <= 50)
            {
                Console.WriteLine("Oh no, now you've done it. She really did not like that. Circe is now going to turn you and your crew into pigs!");
                Console.WriteLine(myStory1.contentArray[17]);
            }
            else
            { 
                if (player1.experience >= 170)
                {
                    Console.WriteLine($"You've gathered {player1.experience} experience points. She sends you home with some magic potions for your journey. ");
                    Console.WriteLine($"You've also gathered {player1.flowers} flowers to give to Circe. She sends you home with some more medical herbs for your journey. ");
                }
                else
                {
                    Console.WriteLine($"You've also gathered {player1.flowers} flowers to give to Circe. She sends you home with some more medical herbs for your journey. ");
                }  

            }
            Console.WriteLine(myStory1.contentArray[20]);
            Console.ReadKey();
        }

    }
}
