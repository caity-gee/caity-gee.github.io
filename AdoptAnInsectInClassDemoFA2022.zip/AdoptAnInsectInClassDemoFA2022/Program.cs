﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoptAnInsectInClassDemoFA2022
{
    class Program
    {
        static void Main(string[] args)
        {
            //instatiate a new game object
            Game myGame1 = new Game();

            //method call against startup()
            myGame1.Startup();
        }
    }
}
