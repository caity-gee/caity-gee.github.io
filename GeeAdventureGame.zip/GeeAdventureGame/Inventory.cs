﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeeAdventureGame
{ 
    public class Inventory
    {
        //the following array maps to bucket, rope, planks, medical supplies, barley, map, compass, bedding
        public int[] items = new int[8] { 0, 0, 0, 0, 0, 0, 0, 0 };
        public List<string> inventoryList = new List<string>();


        public void addInventoryItem(int _item)
        {
            items[_item] = 1;
        }
    }
}

