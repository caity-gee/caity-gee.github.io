﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceRPGDemoSP2022
{
    //setting the access modifier to public
    public class Game
    {
        //create a var to receive the character name form the player
        string inputCharName;

        //create a var to store user menu input
        int userMenuInput;

        //create a var to run our menu loop
        bool running = true;

        //create vars for the player objects
        Ranger myChar1;
        Wizard myChar2;

        //instantiate the Orc
        NPC npc1 = new Orc();

        //instantiate the Story object, this will create the contentArray
        Story myStory1 = new Story();

        //instantiate inventory
        Inventory myInventory1 = new Inventory(); 

        

        //create a method to play the game
        public void PlayGame()
        {
            //launch the first scene
            Scene1();
            Scene2();

        }

        //create a method to update(print to screen) the character HUD
        public void UpdateCharHUD()
        {
            this.myChar1.CharHUD();
        }

        //create an update HUD method for character 2
        public void UpdateChar2HUD()
        {
            this.myChar2.CharHUD();
        }

        //create a method to update the npc HUD
        public void UpdateNPCHUD()
        {
            this.npc1.NPCHUD();
        }

        //create a method to update inventory in HUD
        public void UpdateInventory()
        {
            Console.WriteLine("Inventory:");
            foreach (string i in myInventory1.inventoryList)
            {
                Console.WriteLine(i);
            }
        }

        //create a method for Ranger to Strike
        public int RangerStrike()
        {
            return this.myChar1.Strike();
        }

        //create a method for the Wizard to cast a spell
        public int WizardCastSpell()
        {
            return this.myChar2.CastSpell;
        }

        //create a method for the Wizard to Strike
        public int WizardStrike()
        {
            return this.myChar2.Strike();
        }

        //start building out the menu system for melee
        public void RangerMelee()
        {
            Console.Clear();
            Console.WriteLine("Let's attack the {0}, with the {1}.\n", this.npc1.GetNPCClassName, this.myChar1.GetCharClass);

            //inflict damage on the orc
            npc1.SetNPCHealthPoints = npc1.GetNPCHealthPoints - RangerStrike() ;

            //npc health check
            NPCHealthCheck();

            //update the HUDs
            UpdateCharHUD();
            UpdateChar2HUD();
            UpdateNPCHUD();
            UpdateInventory();
        }

        //create a methode for spell casting melee
        public void WizardSpellMelee()
        {
            Console.Clear();
            Console.WriteLine("Let's cast a spell on the {0}, with the {1}.\n", this.npc1.GetNPCClassName, this.myChar2.GetCharClass);

            //inflict spell damage on the orc
            npc1.SetNPCHealthPoints = npc1.GetNPCHealthPoints - WizardCastSpell();

            //npc health check
            NPCHealthCheck();

            //update the HUDs
            UpdateCharHUD();
            UpdateChar2HUD();
            UpdateNPCHUD();
            UpdateInventory();
        }

        //create a method for the wizard strike melee
        public void WizardStrikeMelee()
        {
            Console.Clear();
            Console.WriteLine("Let's strike the {0}, with the {1}.\n", this.npc1.GetNPCClassName, this.myChar2.GetCharClass);

            //inflict strike on the orc
            npc1.SetNPCHealthPoints = npc1.GetNPCHealthPoints - WizardStrike();

            //npc health check
            NPCHealthCheck();

            //update the HUDs
            UpdateCharHUD();
            UpdateChar2HUD();
            UpdateNPCHUD();
            UpdateInventory();
        }

        //create our menu method
        public void Menu()
        {
            Console.WriteLine("\n1) Strike with the Ranger.");
            Console.WriteLine("2) Strike with the Wizard.");
            Console.WriteLine("3) Cast a Spell with the Wizard.");

            userMenuInput = Convert.ToInt16(Console.ReadLine());

            switch (userMenuInput)
            {
                case 1:
                    RangerMelee();
                    break;
                case 2:
                    WizardStrikeMelee();
                    break;
                case 3:
                    WizardSpellMelee();
                    break;
                default:
                    Console.WriteLine("Please make a valid selection.");
                    break;
            }
        }

        //create a method to check npc helath point values
        public void NPCHealthCheck()
        {
            if (this.npc1.GetNPCHealthPoints <= 0)
            {
                this.npc1.SetNPCHealthPoints = 0;

                Console.Clear();

                //reward the adventure party
                this.myChar1.GainXP(npc1.GetNPCXPValue);
                this.myChar2.GainXP(npc1.GetNPCXPValue);

                UpdateCharHUD();
                UpdateChar2HUD();
                UpdateNPCHUD();
                UpdateInventory();

                Console.WriteLine("\nCongratulations, your adventure party has defeated the {0}.", this.npc1.GetNPCClassName);
                Console.WriteLine("Press enter to continue...");
                Console.ReadLine();

                //terminate the while loop
                running = false;
            }
        }



        //create a method for scene #1
        public void Scene1()
        {
            //ask the player to provide a charname
            Console.WriteLine(myStory1.contentArray[0]);

            inputCharName = Console.ReadLine();

            //instantiate a ranger and feed its contructor the 
            //player provided character name
            myChar1 = new Ranger(inputCharName);


            //clear the console window
            Console.Clear();

            //update the HUD
            UpdateCharHUD();

            //recall the character name
            Console.WriteLine("Welcome, {0} to our adventure!", myChar1.GetCharName);
            Console.WriteLine(myStory1.contentArray[2]);

            Console.ReadLine();

            Console.Clear();
            //instantiate the wizard
            myChar2 = new Wizard("Gandalf");

            Console.WriteLine("{0} the {1} has joined your adventure party.\n", this.myChar2.GetCharName, this.myChar2.GetCharClass);

            //hold console open
            Console.ReadLine();
            Console.WriteLine(myStory1.contentArray[1]);

            //bring up the HUDs
            Console.Clear();

            UpdateCharHUD();

            UpdateChar2HUD();

            UpdateNPCHUD();

            UpdateInventory();

            Console.ReadLine();

            Console.WriteLine(myStory1.contentArray[3]);
            Console.WriteLine(myStory1.contentArray[1]);

            Console.ReadLine();

            Console.Clear();

            //introduce the menu system while loop
            while (running)
            {
                Menu();
            }


            Console.Clear();

            //player earns the first ring for defeating Orc
            Console.WriteLine(myStory1.contentArray[5]);
            myInventory1.AddInventoryItem("silver ring");

            UpdateCharHUD();

            UpdateChar2HUD();

            UpdateNPCHUD();

            UpdateInventory();

            Console.ReadLine();

            Console.Clear();

        }

        //add method for scene 2
        public void Scene2()
        {
            

            Console.WriteLine(myStory1.contentArray[1]);

            Console.ReadLine();

            Console.Clear();


            //cave or forest
            Console.WriteLine(myStory1.contentArray[6]);
            userMenuInput = Convert.ToInt32(Console.ReadLine());
            switch (userMenuInput)
            {
                case 1:
                    Console.WriteLine(myStory1.contentArray[7]);
                    npc1 = new Bugbear();
                    break;
                case 2:
                    Console.WriteLine(myStory1.contentArray[8]);
                    npc1 = new Minotaur();
                    break;
                default:
                    Console.WriteLine(myInventory1.inventoryList[4]);
                    break;
            }

            Console.Clear();

            running = true;

            //introduce the menu system while loop
            while (running)
            {
                Menu();
            }

            //bugbear or minotaur defeated
            switch (npc1.GetNPCClassName)
            {
                case "Bugbear":
                    Console.Clear();
                    Console.WriteLine(myStory1.contentArray[9]);
                    myInventory1.AddInventoryItem("platinum ring");
                    break;
                case "Minotaur":
                    Console.Clear();
                    Console.WriteLine(myStory1.contentArray[10]);
                    myInventory1.AddInventoryItem("bronze ring");
                    break;

            }



            Console.ReadLine();

            UpdateCharHUD();

            UpdateChar2HUD();

            UpdateNPCHUD();

            UpdateInventory();

            Console.ReadLine();

        }


    }
}
