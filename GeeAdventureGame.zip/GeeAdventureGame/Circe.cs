﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeeAdventureGame
{
    public class Circe : Person
    {
        public int points;

        public Circe()
        {
            this.points = 100;
        }

        public void MadPoints(int _MadPoints)
        {
            this.points = this.points + _MadPoints;
        }
    }
}
