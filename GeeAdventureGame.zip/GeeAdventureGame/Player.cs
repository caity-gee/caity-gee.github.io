﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeeAdventureGame
{
    public class Player : Person
    {
        public int[] items = new int[8] { 0, 0, 0, 0, 0, 0, 0, 0 };
        public int experience;
        public int flowers;

        public Player()
        {
            // Does nothing but create object
        }

        public void addInventoryItem(int _item)
        {
            items[_item] = 1;
        }

        public void GainXP(int _experienceInput)
        {
            this.experience = _experienceInput + this.experience;
        }

        public void showXP()
        {
            Console.WriteLine($"{this.experience} experience");
        }

        public void gatherFlowers( int _countFlowers)
        {
            this.flowers = _countFlowers + this.flowers;
        }

        public void showFlowers()
        {
            Console.WriteLine($"{this.flowers} flowers");
        }
    }
}
