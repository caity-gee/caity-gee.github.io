﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceRPGDemoSP2022
{
    //set access modifier to public
    public class Inventory
    {
        //create an inventory list
        public List<string> inventoryList = new List<string>();

        //create a method to add an item.
        //will require an input parameter
        public void AddInventoryItem(string _item)
        { 
            inventoryList.Add(_item);
        }


    }
}
