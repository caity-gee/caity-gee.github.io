﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceRPGDemoSP2022
{
    //set the access modifier to public
    public class Character
    {
        //vars must be me "protected" inorder to become
        //inheritable by child classes
        protected string charName;
        protected string charClass;
        protected string charAlignment;
        protected int healthPoints;
        protected int xp;
        protected int damage;

        //create a custom constructor
        //take in one parameter - input
        public Character(string _charName)
        {
            //marry the input paramater to the base class variable
            this.charName = _charName;

            //set some default values
            this.healthPoints = 100;
            this.xp = 0;
            this.charAlignment = "Neutral";
        }

        //create a public property to be able to read the vlaue
        //stored in the charName field
        public string GetCharName
        {
            get { return this.charName; }
        }

        //create a public property to read the value of charClass
        //stored in the charClass field
        public string GetCharClass
        {
            get { return this.charClass; }
        }

        //create the character HUD method
        public void CharHUD()
        {
            Console.WriteLine("Character Name: {0}", this.charName);
            Console.WriteLine("Character Class: {0}", this.charClass);
            Console.WriteLine("Character Alignment: {0}", this.charAlignment);
            Console.WriteLine("HeathPoints: {0}", this.healthPoints);
            Console.WriteLine("XP: {0}\n", this.xp);
        }

        //create a Strike method
        public int Strike()
        {
            return this.damage;
        }

        //create a method to gain xp
        public void GainXP(int _xpValue)
        {
            this.xp += _xpValue;
        }
    }
}
